<?php
// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the job ID
  $job_id = $_POST["job_id"];
  
  // Connect to the database
  $servername = "your_servername";
  $username = "your_username";
  $password = "your_password";
  $dbname = "your_dbname";
  
  $conn = new mysqli($servername, $username, $password, $dbname);
  
  // Check if the connection was successful
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  
  // Insert a new application into the database
  $sql = "INSERT INTO applications (job_id) VALUES ('$job_id')";
  
  if ($conn->query($sql) === TRUE) {
    echo "Application submitted successfully";
  } else {
    echo "Error submitting application: " . $conn->error;
  }
  
  // Close the database connection
  $conn->close();
}
?>
